<?php
$row_projet_style =     array(
        "id_style_page_auto" => "4",
        "id_general" => "",
        "name_style_pages" => "xaxaa",
        "header_style_pages" => "",
        "total_style_pages" => "",
        "total_style_parent_pages" => "",
        "total_style_text_pages" => "",
        "id_sha1_style_page" => "1742220679_712",
        "id_style_page" => "",
        "id_user_style_page" => "1740105192",
        "date_inscription_style_page" => "2025-03-17 15:11:19",
);
?>