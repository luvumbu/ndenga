<?php
$row_projet_style =     array(
        "id_style_page_auto" => "1",
        "id_general" => "",
        "name_style_pages" => "NOM",
        "header_style_pages" => "",
        "total_style_pages" => "98,97,99,107,103,114,111,117,110,100,45,99,111,108,111,114,58,111,114,97,110,103,101,59,32",
        "total_style_parent_pages" => "98,97,99,107,103,114,111,117,110,100,45,99,111,108,111,114,58,98,108,117,101,59,32",
        "total_style_text_pages" => "98,97,99,107,103,114,111,117,110,100,45,99,111,108,111,114,58,111,114,97,110,103,101,59,32",
        "id_sha1_style_page" => "1742215263_959",
        "id_style_page" => "",
        "id_user_style_page" => "1740105192",
        "date_inscription_style_page" => "2025-03-17 15:59:12",
);
?>