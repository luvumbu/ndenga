<?php 
$dbname = "u489596434_luvumbu";
$username = "v3p9r3e@59A";
$admin_id_sha1_user  = "1742883719";
?>
