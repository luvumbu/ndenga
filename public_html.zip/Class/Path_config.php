<?php 
$config_dbname ="root";
$config_password ="root";
?>