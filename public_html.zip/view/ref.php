<?php

require 'view/model_blog1.php';
require 'view/model_blog2.php';
require 'view/model_blog3.php';




 




 






 
 
$finalArray = [

   "admin" =>     $id_sha1_user_array,
   "projet_1" =>  $projet_1,
   "projet_2" =>  $projet_2

];


 