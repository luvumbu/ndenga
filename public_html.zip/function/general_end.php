<?php 
require_once "general_start.php";
$servername = "localhost";
$src_general1 = "Class/" ;
require_once $src_general1."dbCheck.php";
require_once $src_general1."Give_url.php";
require_once $src_general1."DatabaseHandler.php";
require_once $src_general1."AsciiConverter.php";
$databaseHandler = new DatabaseHandler($dbname, $username);
$option0_1 =$_SESSION["option0_1"];
$option0_2 =$_SESSION["option0_2"];
$option1_1 =$_SESSION["option1_1"];
$option1_2 =$_SESSION["option1_2"];
$option2_1 =$_SESSION["option2_1"];
$option2_2 =$_SESSION["option2_2"];
$option3_1 =$_SESSION["option3_1"];
$option3_2 =$_SESSION["option3_2"];
switch ($option0_1) {
case "1":
$nom_table = $dbname;
$req_sql = "SELECT * FROM `$option0_2` WHERE $option1_1 = '$option1_2'";
$databaseHandler->getListOfTables_Child($option0_2);
$databaseHandler->getDataFromTable2X($req_sql);
$databaseHandler->get_dynamicVariables();
break;
case "2":
$nom_table = $dbname;
$req_sql = "SELECT * FROM `$nom_table` WHERE $option1_1 = '$option1_2' AND $option2_1 = '$option2_2'";
$databaseHandler->getListOfTables_Child($nom_table);
$databaseHandler->getDataFromTable2X($req_sql);
$databaseHandler->get_dynamicVariables();
break;
}
?>