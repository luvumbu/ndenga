<?php
require_once '../Class/DatabaseHandler.php';
require_once '../Class/dbCheck.php';
require_once '../DatabaseHandler/auto_exe.php';
?>


 