<?php
$row_comment_projet = 
array(
    array(
        "id_comment_projet" => "1",
        "id_general" => "1742883567_30",
        "id_user_sha1_comment_projet" => "1740105192",
        "id_user_projet" => "",
        "text_comment_projet" => "109,111,110,32,48,49",
    ),
    array(
        "id_comment_projet" => "2",
        "id_general" => "1742883596_76",
        "id_user_sha1_comment_projet" => "1740105192",
        "id_user_projet" => "",
        "text_comment_projet" => "48,50",
    ),
);
?>