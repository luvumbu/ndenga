<?php
$row_comment_projet = 
array(
    array(
        "id_comment_projet" => "3",
        "id_general" => "1742910921_87",
        "id_user_sha1_comment_projet" => "",
        "id_user_projet" => "",
        "text_comment_projet" => "120,120,120,120,120,120,120,120,120",
    ),
    array(
        "id_comment_projet" => "4",
        "id_general" => "1742910924_55",
        "id_user_sha1_comment_projet" => "",
        "id_user_projet" => "",
        "text_comment_projet" => "",
    ),
    array(
        "id_comment_projet" => "5",
        "id_general" => "1742910928_92",
        "id_user_sha1_comment_projet" => "",
        "id_user_projet" => "",
        "text_comment_projet" => "120,120,120,120,120,120,120",
    ),
    array(
        "id_comment_projet" => "6",
        "id_general" => "1742910958_59",
        "id_user_sha1_comment_projet" => "1742883719",
        "id_user_projet" => "",
        "text_comment_projet" => "108,111,108",
    ),
    array(
        "id_comment_projet" => "7",
        "id_general" => "1742918524_48",
        "id_user_sha1_comment_projet" => "1742883719",
        "id_user_projet" => "",
        "text_comment_projet" => "111,107,32,112,111,117,114,32,109,111,105",
    ),
);
?>