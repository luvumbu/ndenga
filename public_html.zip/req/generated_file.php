<?php
$div = "<div class=\"projet_1_data\"><div style=\'margin-top:0px\'   id=\'id_1737874719_998\' class=\'1737874719_998 section_1 hexagon colors_array_0 hover_cursor\' onclick=\'function_projet_2(this)\'>Reuinion galaxy</div></div><div class=\"id_des_2 total\"><b> Total element : 1</b></div></div>
 <div id=\"countdown-0\" class=\"countdown-container\">
   <div class=\"event-name\">Reuinion galaxy</div> <!-- Afficher le nom de l\'événement -->
   <div class=\"time\">
     <span id=\"years-0\">0</span>
     <span class=\"label\">Années</span>
   </div>
   <div class=\"time\">
     <span id=\"days-0\">30</span>
     <span class=\"label\">Jours</span>
   </div>
   <div class=\"time\">
     <span id=\"hours-0\">2</span>
     <span class=\"label\">Heures</span>
   </div>
   <div class=\"time\">
     <span id=\"minutes-0\">3</span>
     <span class=\"label\">Minutes</span>
   </div>
   <div class=\"time\">
     <span id=\"seconds-0\">31</span>
     <span class=\"label\">Secondes</span>
   </div>
 </div>
  <div class=\"id_des_2\">
    <b>1737874719_998</b>
  
    <div class=\"h1\">
      Reuinion galaxy
    </div>
  
    <div class=\"taille_img\">
      <img src=\"../src/img/1737837937/1737923635.jpeg\" alt=\"\" srcset=\"\">
    </div>
  
    <div>
      <div>
        <b class=\"grey_\">2025-01-26 21:34:02</b>
      </div><br/></div><div id=\"comment_1737874719_998\"></div>
    <h3 style=\"margin-top:75px\">Ajouter un commentaire</h3>
    
    <div class=\"div_comment\">
      <div>
        <textarea name=\"\" id=\"text_1737874719_998\" placeholder=\"votre text\"></textarea>
      </div>
      <div onclick=\"envoie_comment(this)\" class=\"1737874719_998 val_comment_function\"> ENVOYER</div>
    </div>
    
    </div><link rel=\"stylesheet\" href=\"../css_data.css\">";

?>