 <img src="https://www.gmao.com/wp-content/uploads/etablir-un-plan-de-maintenance-preventive-efficace.png" alt="" srcset="">
